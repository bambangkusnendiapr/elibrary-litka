

<?php $__env->startSection('buku','active'); ?>

<?php $__env->startSection('content'); ?>

<!-- Content Header (Page header) -->
<section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Data Buku</h1>
            <!-- <?php if(session('status')): ?>
              <div class="alert alert-success alert-dismissible mt-3">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <h5><i class="icon fas fa-check"></i> Selamat!</h5>
                <?php echo e(session('status')); ?>

              </div>
            <?php endif; ?> -->
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">

      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <!-- Default box -->
            <div class="card">
              <div class="card-header">
              <a href="<?php echo e(route('buku.create')); ?>" class="btn btn-primary"><i class="fas fa-plus"></i>&nbsp;Tambah Buku</a>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <table id="example1" class="table table-striped">
                  <thead>
                  <tr>
                    <th>#</th>
                    <th>Gambar</th>
                    <th>Judul</th>
                    <th>Pengarang</th>
                    <th>Kategori</th>
                    <th>Penerbit</th>
                    <th>Tahun</th>
                    <th>Kota</th>                    
                    <th>JML Lihat</th>
                    <th>Keterangan</th>
                    <th>Aksi</th>
                  </tr>
                  </thead>
                  <tbody>
                  <?php $__currentLoopData = $buku; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e=>$k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($e+1); ?></td>
                    <td>
                    <?php if($k->buku_gambar): ?>
                      <a href="<?php echo e(route('buku_sungle', $k->buku_slug)); ?>" target="_blank">
                        <img id="img" src="<?php echo e(url('images/')); ?>/<?php echo e($k->buku_gambar); ?>" width="70px"/>
                      </a>
                    <?php else: ?>
                      <a href="#">
                        <img id="img" src="<?php echo e(url('images/avatar.jpg')); ?>" width="70px"/>                      
                      </a>
                    <?php endif; ?>
                    </td>
                    <td>
                      <a href="<?php echo e(route('buku_sungle', $k->buku_slug)); ?>" target="_blank">
                        <?php echo e($k->buku_judul); ?>

                      </a>
                    </td>
                    <td><?php echo e($k->pengarang->pengarang_nama); ?></td>
                    <td><?php echo e($k->kategori->kategori_nama); ?></td>
                    <td><?php echo e($k->penerbit->penerbit_nama); ?></td>
                    <td><?php echo e(Carbon\Carbon::parse($k->buku_tahun)->year); ?></td>
                    <td><?php echo e($k->buku_kota); ?></td>                    
                    <td><?php echo e($k->buku_lihat); ?> x lihat</td>
                    <td><?php echo e($k->buku_ket); ?></td>
                    <td>
                      <a href="<?php echo e(route('buku.edit',$k->id)); ?>" class="btn btn-warning btn-sm" title="Edit Buku"><i class="fas fa-edit"></i></a>
                      <a href="#" data-target="#modal-hapus<?php echo e($k->id); ?>" class="btn btn-danger btn-sm" data-toggle="modal" title="Hapus Buku"><i class="fas fa-trash"></i></a>
                      <a href="<?php echo e(route('buku_sungle', $k->buku_slug)); ?>" class="btn btn-sm btn-primary" title="Lihat/Baca Buku"><i class="fas fa-book"></i></a>
                    <a href="<?php echo e(route('download.file', $k->buku_file)); ?>" target="_blank" class="btn btn-sm btn-success"><i class="fas fa-download" title="Download"></i></a>
                    </td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
        </div>
      </div>
    </section>
    <!-- /.content -->

<?php $__currentLoopData = $buku; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="modal fade" id="modal-hapus<?php echo e($k->id); ?>">
    <div class="modal-dialog modal-sm">
      <div class="modal-content">
        <div class="modal-header bg-danger">
          <h4 class="modal-title modal_pc">Konfirmasi Hapus</h4>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <div class="container">
            <div class="row">
              <p>Yakin ingin dihapus?</p>
              <form action="<?php echo e(route('buku.destroy', $k->id)); ?>" method="post" class="d-inline" id="id_form">
              <?php echo method_field('delete'); ?>
              <?php echo csrf_field(); ?>
              <input type="hidden" value="" id="<?php echo e($k->id); ?>">
            </div>
          </div>
                          
        </div>
        <div class="modal-footer justify-content-between">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-danger">Hapus</button>
        </div>
        </form>
      </div>
      <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
  </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->startPush('css'); ?>
<!-- DataTables -->
<link rel="stylesheet" href="<?php echo e(url('adminlte/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(url('adminlte/plugins/datatables-responsive/css/responsive.bootstrap4.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
<!-- DataTables -->
<script src="<?php echo e(url('adminlte/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(url('adminlte/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(url('adminlte/plugins/datatables-responsive/js/dataTables.responsive.min.js')); ?>"></script>
<script src="<?php echo e(url('adminlte/plugins/datatables-responsive/js/responsive.bootstrap4.min.js')); ?>"></script>

<script>
  $(function () {
    $("#example1").DataTable({
      "responsive": false,
      "autoWidth": true,
      "scrollX": true,
    });
    $('#example2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
      "responsive": true,
    });

  });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\pc\Documents\3. Nitip Kusnendi\1. Pemuda\PD\elibrary\resources\views/buku/buku.blade.php ENDPATH**/ ?>