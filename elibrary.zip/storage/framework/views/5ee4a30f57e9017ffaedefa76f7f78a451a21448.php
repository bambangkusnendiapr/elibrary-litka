

<?php $__env->startSection('front_buku','active'); ?>

<?php $__env->startSection('front_content'); ?>

<!-- ======= Breadcrumbs ======= -->
<section class="breadcrumbs">
  <div class="container">

    <div class="d-flex justify-content-between align-items-center">
      <h2>Daftar Buku</h2>
      <ol>
        <li><a href="<?php echo e(route('front')); ?>">Home</a></li>
        <li>Buku</li>
      </ol>
    </div>

  </div>
</section><!-- End Breadcrumbs -->

<section class="inner-page">
  <div class="container">
    <div class="row">
      <div class="col-12">

        <div class="card">
          <!-- /.card-header -->
          <div class="card-body">
            <table id="example1" class="table table-striped">
              <thead>
              <tr class="text-center">
                <th>#</th>
                <th>GAMBAR</th>
                <th>JUDUL</th>
                <th>PENGARANG</th>
                <th>LIHAT</th>
                <th>AKSI</th>                
              </tr>
              </thead>
              <?php $__currentLoopData = $buku; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e=>$data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td class="text-center"><?php echo e($e+1); ?></td>
                  <td class="text-center">
                    <?php if($data->buku_gambar): ?>
                      <a href="<?php echo e(route('buku_sungle', $data->buku_slug)); ?>">
                        <img id="img" src="<?php echo e(url('images/')); ?>/<?php echo e($data->buku_gambar); ?>" width="70px"/>
                      </a>
                    <?php else: ?>
                      <a href="#">
                        <img id="img" src="<?php echo e(url('images/avatar.jpg')); ?>" width="70px"/>                      
                      </a>
                    <?php endif; ?>
                  </td>
                  <td class="align-middle"><a href="<?php echo e(route('buku_sungle', $data->buku_slug)); ?>"><?php echo e($data->buku_judul); ?></a></td>
                  <td class="align-middle"><?php echo e($data->pengarang->pengarang_nama); ?></td>
                  <td class="text-right align-middle"><?php echo e($data->buku_lihat); ?> x lihat</td>
                  <td class="text-center align-middle">
                    <a href="<?php echo e(route('buku_sungle', $data->buku_slug)); ?>" class="btn btn-sm btn-primary" title="Lihat/Baca Buku"><i class="icofont-book"></i></a>
                    <a href="<?php echo e(route('download.file', $data->buku_file)); ?>" target="_blank" class="btn btn-sm btn-success"><i class="icofont-download-alt" title="Download"></i></a>
                  </td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <tbody>
              </tbody>
            </table>
          </div>
          <!-- /.card-body -->
        </div>

      </div>
    </div>
  </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\pc\Documents\3. Nitip Kusnendi\1. Pemuda\PD\elibrary\resources\views/front/front_buku.blade.php ENDPATH**/ ?>