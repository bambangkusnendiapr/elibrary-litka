<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>E-Library Login</title>
  
  <meta name="viewport" content="width=device-width, initial-scale=1">

  
  <link rel="stylesheet" href="<?php echo e(url('adminlte/plugins/fontawesome-free/css/all.min.css')); ?>">
  
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  
  <link rel="stylesheet" href="<?php echo e(url('adminlte/plugins/icheck-bootstrap/icheck-bootstrap.min.css')); ?>">
  
  <link rel="stylesheet" href="<?php echo e(url('adminlte/dist/css/adminlte.min.css')); ?>">
  
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
</head>

<div class="hold-transition login-page">
  <div class="login-box">
    <div class="login-logo">
      <img src="<?php echo e(url('assets/img/logo.png')); ?>" width="75%" height="75%">
    </div>
    

    <div class="login-box-body">
      <div class="card">
        <?php if($message = Session::get('store')): ?>
          <div class="card-header text-center"><?php echo e($message); ?></div>
        <?php endif; ?>
        <div class="card-body login-card-body">
          
          <form action="<?php echo e(route('login')); ?>" method="post">
            <?php echo csrf_field(); ?>

            <div class="input-group mb-3">
              <input id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" placeholder="Email" required autofocus>
              <div class="input-group-append">
                <div class="input-group-text">
                  <span class="fas fa-envelope"></span>
                </div>
              </div>
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="input-group mb-3">
              <input id="password-field" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" placeholder="Password" required autocomplete="current-password">
              <div class="input-group-append">
                <div class="input-group-text">
                  <span class="fas fa-lock"></span>
                </div>
              </div>
                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="row">
              <div class="col-8">
                <span toggle="#password-field" class="fa fa-eye toggle-password"> Show / Hide Password</span>
              </div>
              
              <div class="col-4">
                <button type="submit" class="btn btn-primary btn-block btn-flat"><span class="fas fa-sign-in-alt"></span> Sign In</button>
              </div>
              
            </div>
          </form>
          

        </div>
        
      </div>
    </div>
  </div>
  
</div>


<script src="<?php echo e(url('adminlte/plugins/jquery/jquery.min.js')); ?>"></script>

<script src="<?php echo e(url('adminlte/plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>

<script src="<?php echo e(url('adminlte/dist/js/adminlte.min.js')); ?>"></script>

<script src="<?php echo e(url('adminlte/plugins/icheck-bootstrap/icheck-bootstrap.min.js')); ?>"></script>
<script>
  $(function () {
    $('input').iCheck({
      checkboxClass: 'icheckbox_square-blue',
      radioClass: 'iradio_square-blue',
      increaseArea: '20%' /* optional */
    });
  });

  $(".toggle-password").click(function() {

    $(this).toggleClass("fa-eye fa-eye-slash");
        var input = $($(this).attr("toggle"));
    if (input.attr("type") == "password") {
        input.attr("type", "text");
    } else {
        input.attr("type", "password");
    }
  });
</script>

</body>
</html><?php /**PATH C:\Users\pc\Documents\3. Nitip Kusnendi\1. Pemuda\PD\elibrary\resources\views/auth/login.blade.php ENDPATH**/ ?>