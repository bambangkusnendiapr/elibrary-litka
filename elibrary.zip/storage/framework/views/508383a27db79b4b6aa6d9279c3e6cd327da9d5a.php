

<?php $__env->startSection('pengarang','active'); ?>

<?php $__env->startSection('content'); ?>

<?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- Content Header (Page header) -->
<section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Data Pengarang Buku</h1>
            <!-- <?php if(session('status')): ?>
              <div class="alert alert-success alert-dismissible mt-3">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <h5><i class="icon fas fa-check"></i> Selamat!</h5>
                <?php echo e(session('status')); ?>

              </div>
            <?php endif; ?> -->
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">

      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <!-- Default box -->
            <div class="card">
              <div class="card-header">
              <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#modal-default"><i class="fas fa-plus"></i>&nbsp;Tambah Pengarang</button>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <table id="example1" class="table table-bordered table-striped">
                  <thead>
                  <tr>
                    <th>#</th>
                    <th>Nama Pengarang</th>
                    <th>Keterangan</th>
                    <th>Aksi</th>
                  </tr>
                  </thead>
                  <tbody>
                  <?php $__currentLoopData = $pengarang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e=>$p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($e+1); ?></td>
                    <td><?php echo e($p->pengarang_nama); ?></td>
                    <td><?php echo e($p->pengarang_ket); ?></td>
                    <td>
                      <a href="#" data-target="#modal-edit<?php echo e($p->id); ?>" class="btn btn-success btn-sm" data-toggle="modal"><i class="fas fa-edit"></i></a>
                      <a href="#" data-target="#modal-hapus<?php echo e($p->id); ?>" class="btn btn-danger btn-sm" data-toggle="modal"><i class="fas fa-trash"></i></a>
                    </td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
        </div>
      </div>
    </section>
    <!-- /.content -->

<div class="modal fade" id="modal-default">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Form Tambah Pengarang</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
        <div class="modal-body">
          <form role="form" method="post" action="<?php echo e(route('pengarang.store')); ?>" id="form_tambah">
              <?php echo e(csrf_field()); ?>

              <div class="box-body">
                  <div class="form-group">
                    <label for="nama">Nama Pengarang</label>
                    <input type="text" required name="nama" class="form-control kategori_nama" id="kategori_nama" placeholder="Nama Pengarang">
                  </div>
                  <div class="form-group">
                      <label for="ket">Keterangan</label>
                      <textarea class="form-control summernote kategori_ket" name="ket" id="kategori_ket"></textarea>
                  </div>
              </div>
            <div class="modal-footer justify-content-between">
              <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
              <button type="submit" class="btn btn-primary">Simpan</button>
            </div>
          </form>
        </div>
    </div>
  </div>
</div>

<?php $__currentLoopData = $pengarang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="modal fade" id="modal-edit<?php echo e($p->id); ?>">
    <div class="modal-dialog modal-md">
      <div class="modal-content">
        <div class="modal-header bg-success">
          <h4 class="modal-title modal_pc">Form Edit Data</h4>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <form role="form" method="post" action="<?php echo e(route('pengarang.update',$p->id)); ?>" id="form_tambah">
          <?php echo csrf_field(); ?>
          <?php echo method_field('patch'); ?>
              <div class="box-body">
                  <div class="form-group">
                    <label for="nama">Nama Pengarang</label>
                    <input type="text" required name="nama" class="form-control kategori_nama" id="kategori_nama" value="<?php echo e($p->pengarang_nama); ?>">
                  </div>
                  <div class="form-group">
                      <label for="ket">Keterangan Kategori</label>
                      <textarea class="form-control summernote kategori_ket" name="ket" id="kategori_ket"><?php echo e($p->pengarang_ket); ?></textarea>
                  </div>
              </div>
            <div class="modal-footer justify-content-between">
              <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
              <button type="submit" class="btn btn-primary">Edit</button>
            </div>
          </form>
          </div>
      </div>
      <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
  </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__currentLoopData = $pengarang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="modal fade" id="modal-hapus<?php echo e($p->id); ?>">
    <div class="modal-dialog modal-sm">
      <div class="modal-content">
        <div class="modal-header bg-danger">
          <h4 class="modal-title modal_pc">Konfirmasi Hapus</h4>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <div class="container">
            <div class="row">
              <p>Yakin ingin dihapus?</p>
              <form action="<?php echo e(route('pengarang.destroy', $p->id)); ?>" method="post" class="d-inline" id="id_form">
              <?php echo method_field('delete'); ?>
              <?php echo csrf_field(); ?>
              <input type="hidden" value="" id="<?php echo e($p->id); ?>">
            </div>
          </div>
                          
        </div>
        <div class="modal-footer justify-content-between">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-danger">Hapus</button>
        </div>
        </form>
      </div>
      <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
  </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->startPush('css'); ?>
<!-- DataTables -->
<link rel="stylesheet" href="<?php echo e(url('adminlte/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(url('adminlte/plugins/datatables-responsive/css/responsive.bootstrap4.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
<!-- DataTables -->
<script src="<?php echo e(url('adminlte/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(url('adminlte/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(url('adminlte/plugins/datatables-responsive/js/dataTables.responsive.min.js')); ?>"></script>
<script src="<?php echo e(url('adminlte/plugins/datatables-responsive/js/responsive.bootstrap4.min.js')); ?>"></script>

<script>
  $(function () {
    $("#example1").DataTable({
      "responsive": true,
      "autoWidth": false,
    });
    $('#example2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
      "responsive": true,
    });

  });
</script>
<?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\pc\Documents\3. Nitip Kusnendi\1. Pemuda\PD\elibrary\resources\views/masterdata/pengarang.blade.php ENDPATH**/ ?>