<footer class="main-footer">
    <div class="float-right d-none d-sm-block">
      <b>POS Version</b> 1.0
    </div>
    <strong>Copyright &copy; 2020 <a href="https://web.facebook.com/bambang.kusnendiapr.7/">Bambang K. Apr</a>.</strong>
  </footer>